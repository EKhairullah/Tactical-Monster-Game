#ifndef HEXAGONCONTROLLER_H
#define HEXAGONCONTROLLER_H

#include <QObject>
#include <QGraphicsPolygonItem>
#include <QGraphicsScene>
#include <QMap>
#include <QPointF>
#include <unordered_map>
#include <utility>

struct pair_hash {
    std::size_t operator()(const std::pair<int, int>& p) const {
        return std::hash<int>()(p.first) ^ (std::hash<int>()(p.second) << 1);
    }
};

struct Cell {
    char type = '\0';
    bool occupied = false;
    int player = 0; // 0 = none, 1 = player1, 2 = player2
};

class MainWindow; // Forward declaration

class HexagonController : public QObject
{
    Q_OBJECT
public:
    explicit HexagonController(MainWindow* mainWindow, QGraphicsScene* scene);
    ~HexagonController();

    void initializeBoard(const QString& boardFile);
    void setCurrentPlayer(int player);
    void setAgentSelected(bool selected);
    void clearSelection();

    std::pair<int, int> snapToGrid(QPointF scenePos) const;
    // Removed the public handleHexagonClick declaration

    const std::unordered_map<std::pair<int, int>, Cell, pair_hash>& getBoardState() const { return board; }

signals:
    void playerChanged(int newPlayer);

private slots:
    void handleHexagonClick(QPointF scenePos);  // Only keep this one as a slot

private:
    void createHexagon(qreal x, qreal y, QChar ch);
    void updateHexagonColor(QGraphicsPolygonItem* hexItem, int player);
    QColor getPlayerColor(int player) const;

    MainWindow* mainWindow;
    QGraphicsScene* scene;
    std::unordered_map<std::pair<int, int>, Cell, pair_hash> board;
    QMap<std::pair<int, int>, QGraphicsPolygonItem*> hexagonItems;

    const qreal hexWidth = 80;
    const qreal hexHeight = 69.4;
    const int cellWidth = 10;
    const int cellHeight = 32;

    bool agentSelected = false;
    int currentPlayer = 1;
};

#endif // HEXAGONCONTROLLER_H
