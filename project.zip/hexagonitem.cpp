#include "hexagonitem.h"
#include <QGraphicsSceneMouseEvent>
#include <QBrush>

HexagonItem::HexagonItem(QPolygonF polygon, QGraphicsItem *parent)
    : QGraphicsPolygonItem(polygon, parent)
{
    setAcceptHoverEvents(true);
    setFlag(QGraphicsItem::ItemIsSelectable);
}

void HexagonItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsPolygonItem::mousePressEvent(event);
    emit hexagonClicked(mapToScene(event->pos()));  // Emit signal with scene position
    event->accept();
}

void HexagonItem::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    setBrush(QBrush(QColor(200, 200, 255, 100)));  // Light highlight
    QGraphicsPolygonItem::hoverEnterEvent(event);
}

void HexagonItem::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    setBrush(QBrush(Qt::white));  // Reset to default
    QGraphicsPolygonItem::hoverLeaveEvent(event);
}
