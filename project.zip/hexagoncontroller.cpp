#include "hexagoncontroller.h"
#include "mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QGraphicsSceneMouseEvent>
#include <QDebug>
#include <QAbstractAnimation>
#include "hexagonitem.h"
#include <QPropertyAnimation>

HexagonController::HexagonController(MainWindow* mainWindow, QGraphicsScene* scene)
    : mainWindow(mainWindow), scene(scene)
{
}

HexagonController::~HexagonController()
{
    // Clean up if needed
}

void HexagonController::initializeBoard(const QString& boardFile)
{
    // Hexagon shape (pointy top)
    QPolygonF hexagon;
    hexagon << QPointF(hexWidth*0.25, 0)
            << QPointF(hexWidth*0.75, 0)
            << QPointF(hexWidth, hexHeight*0.5)
            << QPointF(hexWidth*0.75, hexHeight)
            << QPointF(hexWidth*0.25, hexHeight)
            << QPointF(0, hexHeight*0.5);

    // Parse the board
    QFile file(boardFile);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QStringList lines;
        QTextStream in(&file);
        while (!in.atEnd()) {
            lines << in.readLine();
        }
        file.close();

        for (int row = 0; row < lines.size()-1; row++) {
            const QString &line = lines[row];
            for (int col = 0; col < line.length()-1; ) {
                if (line[col] == '/') {
                    QChar ch = line[col+1];
                    if (ch == '\\' || ch == '_' || ch == '|') {
                        col += 2;
                        continue;
                    }

                    qreal x = (col / 6.0) * hexWidth * 1.5;
                    qreal y = row * hexHeight * 0.5;
                    createHexagon(x, y, ch);
                    col += 5;
                }
                else {
                    col++;
                }
            }
        }
    }
}

void HexagonController::createHexagon(qreal x, qreal y, QChar ch)
{
    QPolygonF hexagon;
    hexagon << QPointF(hexWidth*0.25, 0)
            << QPointF(hexWidth*0.75, 0)
            << QPointF(hexWidth, hexHeight*0.5)
            << QPointF(hexWidth*0.75, hexHeight)
            << QPointF(hexWidth*0.25, hexHeight)
            << QPointF(0, hexHeight*0.5);

    // Use HexagonItem instead of QGraphicsPolygonItem
    HexagonItem* hexItem = new HexagonItem(hexagon);
    hexItem->setPos(x, y);

    // Connect the signal
    connect(hexItem, &HexagonItem::hexagonClicked,
            this, &HexagonController::handleHexagonClick);
    // Set initial color based on content
    if (ch == '1') {
        hexItem->setBrush(QColor(100, 255, 100)); // Light green
    } else if (ch == '2') {
        hexItem->setBrush(QColor(255, 255, 100)); // Yellow
    } else if (ch == '#') {
        hexItem->setBrush(QColor(100, 100, 255)); // Blue
    } else if (ch == '~') {
        hexItem->setBrush(QColor(255, 150, 200)); // Pink
    } else {
        hexItem->setBrush(Qt::white); // Empty
    }

    hexItem->setPen(QPen(Qt::black, 1));
    scene->addItem(hexItem);

    // Store game state
    Cell cell;
    cell.type = (ch == ' ') ? '\0' : ch.toLatin1();
    cell.occupied = (ch == '#' || ch == '~');
    cell.player = (ch == '1') ? 1 : (ch == '2') ? 2 : 0;
    QPointF scenePos(x + hexWidth/2, y + hexHeight/2);
    board[snapToGrid(scenePos)] = cell;
}

QColor HexagonController::getPlayerColor(int player) const
{
    if (player == 1) return QColor(224, 27, 36);    // Red
    if (player == 2) return QColor(39, 174, 96);    // Green
    return Qt::white;
}

void HexagonController::updateHexagonColor(QGraphicsPolygonItem* hexItem, int player)
{
    if (!hexItem) return;

    QColor baseColor = getPlayerColor(player);
    QLinearGradient gradient(hexItem->boundingRect().topLeft(),
                             hexItem->boundingRect().bottomRight());
    gradient.setColorAt(0, baseColor.lighter(120));
    gradient.setColorAt(1, baseColor.darker(120));
    hexItem->setBrush(gradient);
}

std::pair<int, int> HexagonController::snapToGrid(QPointF scenePos) const
{
    int x = static_cast<int>(scenePos.x());
    int y = static_cast<int>(scenePos.y());
    int gridX = (x / cellWidth) * cellWidth;
    int gridY = (y / cellHeight) * cellHeight;
    return {gridX, gridY};
}

void HexagonController::setCurrentPlayer(int player)
{
    currentPlayer = player;
}

void HexagonController::setAgentSelected(bool selected)
{
    agentSelected = selected;
}

void HexagonController::clearSelection()
{
    agentSelected = false;
}

void HexagonController::handleHexagonClick(QPointF scenePos)
{
    // Debug output to verify click position
    qDebug() << "Hexagon clicked at scene position:" << scenePos;

    if (!agentSelected) {
        QMessageBox::information(mainWindow,
                                 "No Agent Selected",
                                 "Please select an agent first by clicking an agent button.");
        return;
    }

    // Find the topmost item at the click position
    QGraphicsItem* clickedItem = scene->itemAt(scenePos, QTransform());
    if (!clickedItem) {
        qDebug() << "No item found at click position";
        return;
    }

    // Try to get the HexagonItem (either directly or through parent)
    HexagonItem* hexItem = dynamic_cast<HexagonItem*>(clickedItem);
    if (!hexItem) {
        hexItem = dynamic_cast<HexagonItem*>(clickedItem->parentItem());
        if (!hexItem) {
            qDebug() << "Clicked item is not a hexagon";
            return;
        }
    }

    // Calculate the grid position from the hexagon's center
    QPointF hexCenter = hexItem->boundingRect().center() + hexItem->pos();
    auto gridPos = snapToGrid(hexCenter);
    qDebug() << "Hexagon center at grid position:" << gridPos.first << gridPos.second;

    // Find the cell in our game board
    auto it = board.find(gridPos);
    if (it == board.end()) {
        qDebug() << "No cell found at grid position";
        return;
    }

    Cell& cell = it->second;

    // Validate the move
    if (cell.occupied) {
        QMessageBox::information(mainWindow,
                                 "Invalid Move",
                                 "This cell is already occupied.");
        qDebug() << "Cell is already occupied";
        return;
    }

    if ((currentPlayer == 1 && cell.type != '1') ||
        (currentPlayer == 2 && cell.type != '2')) {
        QMessageBox::information(mainWindow,
                                 "Invalid Move",
                                 "You can only place agents on your own color cells.");
        qDebug() << "Invalid cell type for current player";
        return;
    }

    // Visual feedback - pulse effect
    // In handleHexagonClick, replace the animation code with:
    QPropertyAnimation* anim = new QPropertyAnimation(this);
    anim->setDuration(100);
    anim->setKeyValueAt(0, 1.0);
    anim->setKeyValueAt(0.5, 1.05);
    anim->setKeyValueAt(1, 1.0);
    anim->start(QAbstractAnimation::DeleteWhenStopped);
    // Update the hexagon color
    updateHexagonColor(hexItem, currentPlayer);

    // Update game state
    cell.occupied = true;
    cell.player = currentPlayer;
    qDebug() << "Cell updated - occupied:" << cell.occupied << "player:" << cell.player;

    // Switch turns
    clearSelection();
    currentPlayer = (currentPlayer == 1) ? 2 : 1;
    qDebug() << "Switching to player:" << currentPlayer;

    // Emit signal for UI updates
    emit playerChanged(currentPlayer);
}
